Place target NeoForge MDK projects in `templates/neoforge/<minecraft-version>/` in your template repository.

Each directory should contain a working Gradle project, including its Gradle Wrapper. MVSwithcher clones the repository and uses the requested version directory as the base output project.
