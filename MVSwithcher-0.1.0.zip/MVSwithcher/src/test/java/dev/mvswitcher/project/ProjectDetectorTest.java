package dev.mvswitcher.project;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import java.nio.file.*;
import static org.junit.jupiter.api.Assertions.*;

class ProjectDetectorTest {
    @TempDir Path temp;

    @Test void detectsProjectNameAndMinecraftVersion() throws Exception {
        Files.writeString(temp.resolve("settings.gradle"), "rootProject.name = 'ExampleMod'\n");
        Files.writeString(temp.resolve("gradle.properties"), "minecraft_version=1.21.1\n");
        ProjectInfo info = new ProjectDetector().detect(temp);
        assertEquals("ExampleMod", info.projectName());
        assertEquals("1.21.1", info.minecraftVersion());
    }
}
