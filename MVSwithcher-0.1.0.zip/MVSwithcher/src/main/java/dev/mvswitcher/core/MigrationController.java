package dev.mvswitcher.core;

import dev.mvswitcher.git.TemplateRepository;
import dev.mvswitcher.migration.ApiMigrator;
import dev.mvswitcher.project.ProjectDetector;
import dev.mvswitcher.project.ProjectInfo;
import dev.mvswitcher.project.ProjectExporter;
import dev.mvswitcher.gradle.GradleManager;

import java.nio.file.Files;
import java.nio.file.Path;

public class MigrationController {
    public record Request(Path source, String targetVersion, String loader, String templateRepo,
                          Path output, boolean noBuild, boolean overwrite, boolean keepWork, boolean verbose) {}

    public void run(Request request) throws Exception {
        if (!"neoforge".equalsIgnoreCase(request.loader())) {
            throw new IllegalArgumentException("Only NeoForge is supported in this release.");
        }
        if (!Files.isDirectory(request.source())) throw new IllegalArgumentException("Current directory does not exist.");
        String repo = request.templateRepo();
        if (repo == null || repo.isBlank()) repo = System.getenv("MVS_TEMPLATE_REPO");
        if (repo == null || repo.isBlank()) {
            throw new IllegalArgumentException("Template repository is not configured. Use --template-repo URL or MVS_TEMPLATE_REPO.");
        }

        Path work = request.source().resolve(".mvswitcher").resolve("work-" + System.currentTimeMillis());
        try {
            log(request, "[1/6] Detecting source project...");
            ProjectInfo source = new ProjectDetector().detect(request.source());
            log(request, "[INFO] Project: " + source.projectName() + " | source version: " + source.minecraftVersion());

            log(request, "[2/6] Downloading NeoForge template...");
            Path checkout = new TemplateRepository().cloneRepository(repo, work.resolve("templates"), request.verbose());
            Path template = checkout.resolve("templates").resolve("neoforge").resolve(request.targetVersion());
            if (!Files.isDirectory(template)) {
                throw new IllegalStateException("Template not found: templates/neoforge/" + request.targetVersion());
            }

            log(request, "[3/6] Preparing separate output project...");
            if (request.output().startsWith(request.source())) {
                // Output inside source is allowed; it is excluded from source copy.
            }
            new ProjectExporter().export(source, template, request.output(), request.overwrite());

            log(request, "[4/6] Applying migration rules...");
            ApiMigrator.Result migration = new ApiMigrator().migrate(
                    checkout.resolve("migrations").resolve("neoforge"),
                    source.minecraftVersion(), request.targetVersion(), request.output());
            log(request, "[INFO] Migration rules applied: " + migration.appliedRules()
                    + " | unmatched required rules: " + migration.unmatchedRequired());

            log(request, "[5/6] Configuring project metadata...");
            new ProjectExporter().configureMetadata(request.output(), source, request.targetVersion());

            if (!request.noBuild()) {
                log(request, "[6/6] Running Gradle build...");
                new GradleManager().build(request.output(), request.verbose());
            } else {
                log(request, "[6/6] Build skipped (--no-build).");
            }

            System.out.println("\n[SUCCESS] Migration preparation completed.");
            System.out.println("Output: " + request.output());
            if (migration.unmatchedRequired() > 0) {
                System.out.println("[WARNING] Some required migration rules did not match. Review migration-report.txt.");
            }
        } finally {
            if (!request.keepWork()) FileOps.deleteRecursively(work);
        }
    }

    private void log(Request r, String message) { System.out.println(message); }
}
