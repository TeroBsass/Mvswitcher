package dev.mvswitcher;

import picocli.CommandLine;
import picocli.CommandLine.Command;
import picocli.CommandLine.Option;
import dev.mvswitcher.core.MigrationController;

import java.nio.file.Path;
import java.util.concurrent.Callable;

@Command(name = "mvswitcher", mixinStandardHelpOptions = true,
        version = "MVSwithcher 0.1.0",
        description = "Prepare a NeoForge mod project for another Minecraft version.")
public class Main implements Callable<Integer> {
    @Option(names = "--ver", required = true, description = "Target Minecraft version, e.g. 1.21.11")
    private String targetVersion;

    @Option(names = "--loader", defaultValue = "neoforge", description = "Mod loader (currently: neoforge)")
    private String loader;

    @Option(names = "--template-repo", description = "Git URL for the template repository (or MVS_TEMPLATE_REPO)")
    private String templateRepo;

    @Option(names = "--output", defaultValue = "./converted", description = "Output directory (default: ${DEFAULT-VALUE})")
    private Path output;

    @Option(names = "--no-build", description = "Prepare the converted project without running Gradle")
    private boolean noBuild;

    @Option(names = "--overwrite", description = "Allow replacing an existing output directory")
    private boolean overwrite;

    @Option(names = "--keep-work", description = "Keep temporary downloaded template files")
    private boolean keepWork;

    @Option(names = "--verbose", description = "Print detailed diagnostic output")
    private boolean verbose;

    @Override
    public Integer call() {
        try {
            MigrationController.Request request = new MigrationController.Request(
                    Path.of("").toAbsolutePath().normalize(),
                    targetVersion, loader, templateRepo, output.toAbsolutePath().normalize(),
                    noBuild, overwrite, keepWork, verbose);
            new MigrationController().run(request);
            return 0;
        } catch (Exception e) {
            System.err.println("[ERROR] " + e.getMessage());
            if (verbose) e.printStackTrace(System.err);
            return 1;
        }
    }

    public static void main(String[] args) {
        int exit = new CommandLine(new Main()).execute(args);
        System.exit(exit);
    }
}
