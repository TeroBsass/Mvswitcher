package dev.mvswitcher.git;

import java.io.IOException;
import java.nio.file.*;
import java.util.List;

public class TemplateRepository {
    public Path cloneRepository(String url, Path destination, boolean verbose) throws IOException, InterruptedException {
        Files.createDirectories(destination.getParent());
        ProcessBuilder pb = new ProcessBuilder("git", "clone", "--depth", "1", url, destination.toString());
        if (!verbose) pb.redirectErrorStream(true);
        Process process = pb.inheritIO().start();
        int code = process.waitFor();
        if (code != 0) throw new IOException("git clone failed with exit code " + code + ". Check Git installation and repository URL.");
        return destination;
    }
}
