package dev.mvswitcher.project;

import dev.mvswitcher.core.FileOps;
import java.io.IOException;
import java.nio.file.*;
import java.util.Set;

public class ProjectExporter {
    private static final Set<String> SKIP = Set.of(".git", ".gradle", "build", ".idea", ".vscode", "converted", ".mvswitcher");

    public void export(ProjectInfo source, Path template, Path output, boolean overwrite) throws IOException {
        if (Files.exists(output)) {
            if (!overwrite) throw new IllegalArgumentException("Output already exists: " + output + ". Choose another --output or use --overwrite.");
            FileOps.deleteRecursively(output);
        }
        Files.createDirectories(output);
        FileOps.copyTree(template, output, rel -> true);

        // Merge source src into template src, with source files taking precedence.
        Path sourceSrc = source.root().resolve("src");
        if (Files.exists(sourceSrc)) {
            FileOps.copyTree(sourceSrc, output.resolve("src"), rel -> true);
        }

        // Preserve common mod-specific files, but keep target Gradle scripts/wrapper.
        for (String item : new String[]{"LICENSE", "README.md", "CHANGELOG.md", "LICENSE.txt"}) {
            Path from = source.root().resolve(item);
            if (Files.isRegularFile(from) && !Files.exists(output.resolve(item))) {
                Files.copy(from, output.resolve(item));
            }
        }
        FileOps.copyTree(source.root(), output, rel -> {
            String first = rel.getName(0).toString();
            if (SKIP.contains(first)) return false;
            String p = rel.toString().replace('\\', '/');
            if (p.equals("src") || p.startsWith("src/")) return false;
            if (p.equals("gradle") || p.startsWith("gradle/")) return false;
            if (p.equals("gradlew") || p.equals("gradlew.bat") || p.equals("build.gradle")
                    || p.equals("build.gradle.kts") || p.equals("settings.gradle")
                    || p.equals("settings.gradle.kts") || p.equals("gradle.properties")) return false;
            return !p.startsWith("build/");
        });
    }

    public void configureMetadata(Path output, ProjectInfo source, String targetVersion) throws IOException {
        Path settings = output.resolve("settings.gradle");
        if (Files.exists(settings)) {
            String content = Files.readString(settings);
            content = content.replaceAll("(?m)^\\s*rootProject\\.name\\s*=.*$",
                    "rootProject.name = '" + source.projectName().replace("'", "\\'") + "'");
            if (!content.contains("rootProject.name")) content += "\nrootProject.name = '" + source.projectName() + "'\n";
            Files.writeString(settings, content);
        }
        Path props = output.resolve("gradle.properties");
        if (Files.exists(props)) {
            String content = Files.readString(props);
            content = content.replaceAll("(?m)^minecraft_version\\s*=.*$", "minecraft_version=" + targetVersion);
            Files.writeString(props, content);
        }
        if (source.modId() != null) {
            for (String file : new String[]{"src/main/resources/META-INF/neoforge.mods.toml",
                    "src/main/resources/META-INF/mods.toml"}) {
                Path toml = output.resolve(file);
                if (Files.exists(toml)) {
                    String content = Files.readString(toml);
                    // The mod ID is already retained when the source TOML was merged.
                    if (!content.contains("modId")) System.err.println("[WARN] Could not find modId in target metadata: " + toml);
                }
            }
        }
    }
}
