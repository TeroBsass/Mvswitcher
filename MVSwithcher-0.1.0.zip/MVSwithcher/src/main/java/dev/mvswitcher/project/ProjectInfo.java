package dev.mvswitcher.project;

import java.nio.file.Path;

public record ProjectInfo(Path root, String projectName, String minecraftVersion, String modId) {}
