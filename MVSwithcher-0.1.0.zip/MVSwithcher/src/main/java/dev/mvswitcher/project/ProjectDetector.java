package dev.mvswitcher.project;

import java.io.IOException;
import java.nio.file.*;
import java.util.regex.*;

public class ProjectDetector {
    public ProjectInfo detect(Path root) throws IOException {
        if (!Files.exists(root.resolve("settings.gradle")) && !Files.exists(root.resolve("settings.gradle.kts"))) {
            throw new IllegalArgumentException("No settings.gradle(.kts) found. Run MVSwithcher from a Gradle project root.");
        }
        String settings = readFirst(root.resolve("settings.gradle"), root.resolve("settings.gradle.kts"));
        String name = firstGroup(settings, "rootProject\\.name\\s*=\\s*['\"]([^'\"]+)['\"]");
        if (name == null) name = root.getFileName().toString();

        String properties = Files.exists(root.resolve("gradle.properties"))
                ? Files.readString(root.resolve("gradle.properties")) : "";
        String build = readFirst(root.resolve("build.gradle"), root.resolve("build.gradle.kts"));
        String version = firstGroup(properties + "\n" + build,
                "(?:minecraft_version|minecraftVersion|minecraft)\\s*[=:]\\s*['\"]?([0-9]+\\.[0-9]+(?:\\.[0-9]+)?)");
        String modId = null;
        Path toml = root.resolve("src/main/resources/META-INF/neoforge.mods.toml");
        if (!Files.exists(toml)) toml = root.resolve("src/main/resources/META-INF/mods.toml");
        if (Files.exists(toml)) modId = firstGroup(Files.readString(toml), "modId\\s*=\\s*['\"]([^'\"]+)['\"]");
        return new ProjectInfo(root, name, version == null ? "unknown" : version, modId);
    }

    private String readFirst(Path... paths) throws IOException {
        for (Path p : paths) if (Files.exists(p)) return Files.readString(p);
        return "";
    }
    private String firstGroup(String input, String regex) {
        Matcher m = Pattern.compile(regex, Pattern.CASE_INSENSITIVE).matcher(input);
        return m.find() ? m.group(1) : null;
    }
}
