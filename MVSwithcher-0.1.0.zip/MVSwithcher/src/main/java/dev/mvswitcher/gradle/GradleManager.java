package dev.mvswitcher.gradle;

import java.io.IOException;
import java.nio.file.*;

public class GradleManager {
    public void build(Path project, boolean verbose) throws IOException, InterruptedException {
        boolean windows = System.getProperty("os.name").toLowerCase().contains("win");
        Path wrapper = project.resolve(windows ? "gradlew.bat" : "gradlew");
        String[] command;
        if (Files.exists(wrapper)) {
            if (!windows) wrapper.toFile().setExecutable(true);
            command = windows
                    ? new String[]{"cmd", "/c", "gradlew.bat", "clean", "build"}
                    : new String[]{"./gradlew", "clean", "build"};
        } else {
            command = new String[]{"gradle", "clean", "build"};
        }
        ProcessBuilder pb = new ProcessBuilder(command).directory(project.toFile()).redirectErrorStream(true);
        if (verbose) pb.inheritIO();
        else pb.redirectOutput(project.resolve("mvswitcher-build.log").toFile());
        int code = pb.start().waitFor();
        if (code != 0) throw new IOException("Gradle build failed (exit " + code + "). See mvswitcher-build.log or rerun with --verbose.");
    }
}
