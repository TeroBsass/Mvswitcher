package dev.mvswitcher.migration;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import dev.mvswitcher.core.FileOps;

import java.io.IOException;
import java.nio.file.*;
import java.util.*;
import java.util.regex.Pattern;

public class ApiMigrator {
    public record Result(int appliedRules, int unmatchedRequired) {}

    public Result migrate(Path rulesDirectory, String sourceVersion, String targetVersion, Path project) throws IOException {
        Path rulesFile = rulesDirectory.resolve(sourceVersion + "-to-" + targetVersion + ".json");
        if (!Files.exists(rulesFile)) {
            Files.writeString(project.resolve("migration-report.txt"),
                    "No migration ruleset found for " + sourceVersion + " -> " + targetVersion + ".\n"
                    + "The project was copied without API transformations. Review compatibility manually.\n");
            return new Result(0, 0);
        }
        JsonNode root = new ObjectMapper().readTree(rulesFile.toFile());
        int applied = 0, unmatchedRequired = 0;
        List<String> report = new ArrayList<>();
        for (JsonNode rule : root.path("rules")) {
            String id = rule.path("id").asText("unnamed-rule");
            String glob = rule.path("fileGlob").asText("**/*.java");
            String find = rule.path("find").asText();
            String replace = rule.path("replace").asText();
            boolean required = rule.path("required").asBoolean(false);
            if (find.isEmpty()) { report.add("SKIPPED " + id + ": empty find value"); continue; }
            int matches = 0;
            PathMatcher matcher = FileSystems.getDefault().getPathMatcher("glob:" + glob);
            try (var stream = Files.walk(project.resolve("src"))) {
                for (Path file : stream.filter(Files::isRegularFile).toList()) {
                    Path rel = project.resolve("src").relativize(file);
                    if (!matcher.matches(rel)) continue;
                    String text = Files.readString(file);
                    if (text.contains(find)) {
                        int occurrences = count(text, find);
                        Files.writeString(file, text.replace(find, replace));
                        matches += occurrences;
                    }
                }
            }
            if (matches > 0) { applied++; report.add("APPLIED " + id + ": " + matches + " occurrence(s)"); }
            else {
                report.add((required ? "MISSING REQUIRED " : "NO MATCH ") + id);
                if (required) unmatchedRequired++;
            }
        }
        Files.write(project.resolve("migration-report.txt"), report,
                StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
        return new Result(applied, unmatchedRequired);
    }

    private int count(String text, String needle) {
        int count = 0, at = 0;
        while ((at = text.indexOf(needle, at)) >= 0) { count++; at += needle.length(); }
        return count;
    }
}
