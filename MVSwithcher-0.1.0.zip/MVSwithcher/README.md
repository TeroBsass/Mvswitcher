# MVSwithcher

A Java 21 command-line tool for preparing NeoForge mod projects for another Minecraft version.

> Status: initial MVP scaffold. It can detect a Gradle mod project, fetch a version template repository, copy project sources/resources into a separate output directory, apply explicitly configured migration rules, configure template metadata, and run the target Gradle build. It cannot guarantee that arbitrary mod code can be migrated automatically: API changes require verified migration rules and sometimes manual work.

## Requirements

- Java 21+
- Git installed and available on `PATH`
- Gradle 8.10+ to build MVSwithcher itself (or use a Gradle installation from your IDE)
- The target template repository must follow the layout described below.

## Build

```bash
gradle clean build
```

The fat JAR is created at `build/libs/mvswitcher-0.1.0.jar`.

Run it:

```bash
java -jar build/libs/mvswitcher-0.1.0.jar --help
```

For a globally available `mvswitcher` command, install the Gradle application distribution and add its `bin` directory to `PATH`:

```bash
gradle installDist
```

## Usage

Run from the root of the source mod project:

```bash
mvswitcher --ver 1.21.11
mvswitcher --ver 1.21.11 --template-repo https://github.com/YOUR_ORG/mvswitcher-templates.git
mvswitcher --ver 1.21.11 --output ./converted --no-build
```

Options:

- `--ver`: target Minecraft version (required)
- `--loader`: currently only `neoforge`
- `--template-repo`: Git repository containing templates (or `MVS_TEMPLATE_REPO`)
- `--output`: output project directory (default `./converted`)
- `--no-build`: prepare the project without running Gradle
- `--keep-work`: keep downloaded template/work files for debugging
- `--verbose`: verbose logs

## Template repository contract

The template repository should contain:

```text
templates/
  neoforge/
    1.21.11/
      settings.gradle
      build.gradle
      gradle.properties
      gradlew
      gradlew.bat
      gradle/wrapper/...
      src/main/resources/META-INF/neoforge.mods.toml
migrations/
  neoforge/
    1.21.1-to-1.21.11.json
```

A template must be a working NeoForge MDK project for the requested Minecraft version. Do not commit generated build output.

Migration JSON format:

```json
{
  "sourceVersion": "1.21.1",
  "targetVersion": "1.21.11",
  "rules": [
    {
      "id": "example-rule",
      "description": "Illustrative textual replacement; verify against the NeoForge API",
      "fileGlob": "**/*.java",
      "find": "old.package.Type",
      "replace": "new.package.Type",
      "required": false
    }
  ]
}
```

Rules are deliberately explicit and scoped to files. The MVP applies literal text replacements, not semantic Java refactoring. Prefer exact imports or fully-qualified symbols over broad identifiers. A later release should add AST-based transformations and version-hop planning.

## Safety and behavior

- The source project is never modified.
- Output is created separately. Existing output directories are refused unless `--overwrite` is explicitly supplied.
- `.git`, `.gradle`, `build`, IDE folders, and the source Gradle wrapper are not copied from the source project.
- The target template supplies Gradle build files and wrapper.
- `src` and common project resource/config folders are copied from the source. Template files are retained when source files collide, except source `src` content is merged into template `src`.
- The tool preserves the detected project name and attempts to preserve mod ID in `neoforge.mods.toml`.
- Always review the migration report and test the resulting mod in Minecraft. A successful Gradle build only confirms compilation, not runtime compatibility.

## Current limitations

- NeoForge only.
- One direct source-to-target migration ruleset is loaded; no multi-hop migration graph yet.
- Automatic code migration is limited to declared literal replacements.
- Mod-specific dependencies, mixins, access transformers, generated resources, and complex Gradle customizations may require additional adapters.
- The template repository URL must be configured by the user; no official MVSwithcher template repository is assumed.
